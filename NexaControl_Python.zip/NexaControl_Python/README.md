# NexaControl — Plataforma de Cumplimiento

Versión migrada completamente a **Python + Flask**. Ya no necesita PHP ni AppServ/XAMPP.

## Inicio rápido (Windows)
1. Instala Python 3.11 o superior.
2. Abre CMD/PowerShell dentro de esta carpeta.
3. Ejecuta:
   `python -m venv venv`
4. Activa el entorno:
   PowerShell: `venv\Scripts\Activate.ps1`
   CMD: `venv\Scripts\activate.bat`
5. Instala dependencias: `pip install -r requirements.txt`
6. Inicializa la base: `python init_db.py`
7. Inicia: `python app.py`
8. Abre `http://127.0.0.1:5000`

## Usuarios demo
- Administrador: `admin@nexacontrol.local` / `Admin123*`
- Auditor: `auditor@nexacontrol.local` / `Auditor123*`
- Cliente: `cliente@nexacontrol.local` / `Cliente123*`

## Base de datos
La versión incluida utiliza SQLite para facilitar pruebas. El archivo queda en `instance/nexacontrol.db`.
El proyecto conserva el archivo `database_mysql.sql` para crear la misma estructura en MySQL si deseas desplegarlo en servidor.

## Funciones incluidas
- Inicio de sesión por roles.
- Dashboard de administrador, auditor y cliente.
- Administración de clientes y usuarios.
- Catálogo de requisitos por matriz.
- Importación de la matriz JSON original.
- Carga de evidencias por cliente.
- Vista previa de PDF/imágenes/texto antes de descargar.
- Evaluación del auditor: Cumple, No cumple, Cumple parcial, No entregado y No aplica.
- Hallazgos y planes de remediación.
- Reporte Excel por cliente con resultados y hallazgos.
- Registro básico de actividad.

## Identidad visual
El nombre anterior fue reemplazado por **NexaControl**. El isotipo “NC” se genera con HTML/CSS y no depende de archivos externos. La nueva paleta usa verde petróleo, verde menta y grafito.
